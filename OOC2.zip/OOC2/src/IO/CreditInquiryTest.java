package IO;

public class CreditInquiryTest
{
    public static void main( String args[] )
    {
        CreditInquiry application = new CreditInquiry();
        application.processRequests();
    }
}

