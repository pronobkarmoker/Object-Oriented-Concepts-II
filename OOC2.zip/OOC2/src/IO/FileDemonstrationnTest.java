package IO;
import javax.swing.JFrame;
public class FileDemonstrationnTest {
         public static void main( String args[] )
        {
            FileDemonstrationn application = new FileDemonstrationn();
            application.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
            }
        }
